package com.example.mycalculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val number1 = findViewById<EditText>(R.id.editTextTextPersonName)
        val number2 = findViewById<EditText>(R.id.editTextTextPersonName2)

        val addButton = findViewById<Button>(R.id.button)
        val subtractButton = findViewById<Button>(R.id.button2)
        val multiplyButton = findViewById<Button>(R.id.button3)
        val divideButton = findViewById<Button>(R.id.button4)
        val squareRootButton = findViewById<Button>(R.id.button6)
        val powerButton = findViewById<Button>(R.id.button5)

        val answerTextView = findViewById<TextView>(R.id.textView3)

        addButton.setOnClickListener {
            val num1 = number1.text.toString().toIntOrNull()
            val num2 = number2.text.toString().toIntOrNull()

            if (num1 != null && num2 != null) {
                val result = num1 + num2
                answerTextView.text = "Answer: $num1 + $num2 = $result"
            } else {
                showError()
            }
        }

        // Implement click listeners for other operations in a similar manner.

        squareRootButton.setOnClickListener {
            val num1 = number1.text.toString().toDouble()

            if (num1 >= 0) {
                val result = sqrt(num1)
                answerTextView.text = "sqrt($num1) = $result"
            } else {
                showError("Square root of negative number is not supported.")
            }
        }

        powerButton.setOnClickListener {
            val num1 = number1.text.toString().toDouble()
            val num2 = number2.text.toString().toIntOrNull()

            if (num2 != null) {
                val result = num1.pow(num2)
                answerTextView.text = "$num1^$num2 = $result"
            } else {
                showError()
            }
        }
    }

    private fun showError(message: String = "Invalid input") {
        val toast = Toast.makeText(this, message, Toast.LENGTH_SHORT)
        toast.show()
    }
}
